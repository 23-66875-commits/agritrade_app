package com.example.agritrade_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
