import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';

void main() {
  runApp(const AgriTradeApp());
}


class AgriTradeApp extends StatelessWidget {
  const AgriTradeApp({super.key});
  

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'AgriTrade+',
      theme: ThemeData(
        scaffoldBackgroundColor: const Color(0xFFF7F5EF),
      ),
      home: const SplashScreen(),
    );
  }
}