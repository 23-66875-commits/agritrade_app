import 'package:flutter/material.dart';

class RoleSelectionScreen extends StatelessWidget {
  const RoleSelectionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F5EF),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const SizedBox(height: 20),

            const Icon(
              Icons.agriculture,
              size: 80,
              color: Color(0xFF1B5E20),
            ),

            const SizedBox(height: 10),

            RichText(
              text: const TextSpan(
                children: [
                  TextSpan(
                    text: "Agri",
                    style: TextStyle(
                      color: Color(0xFF1B5E20),
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  TextSpan(
                    text: "Trade+",
                    style: TextStyle(
                      color: Color(0xFFB8860B),
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 40),

            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    const Icon(
                      Icons.agriculture,
                      size: 70,
                      color: Color(0xFF1B5E20),
                    ),

                    const SizedBox(height: 10),

                    const Text(
                      "List your livestock, produce and manage your farm inventory.",
                      textAlign: TextAlign.center,
                    ),

                    const SizedBox(height: 15),

                    ElevatedButton(
                      onPressed: () {},
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF1B5E20),
                        minimumSize: const Size(double.infinity, 50),
                      ),
                      child: const Text(
                        "Login as Farmer",
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 20),

            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    const Icon(
                      Icons.shopping_bag,
                      size: 70,
                      color: Color(0xFF1B5E20),
                    ),

                    const SizedBox(height: 10),

                    const Text(
                      "Source fresh agricultural products directly from farms.",
                      textAlign: TextAlign.center,
                    ),

                    const SizedBox(height: 15),

                    ElevatedButton(
                      onPressed: () {},
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF1B5E20),
                        minimumSize: const Size(double.infinity, 50),
                      ),
                      child: const Text(
                        "Login as Buyer",
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}